#include <FastLED.h> 

#define LED1_PIN 5 // left panel 
#define LED2_PIN 6 // right panel
#define SWITCH_PIN1 7 
#define POT_PIN A0 
#define NUM_LEDS 4 
#define BRIGHTNESS 200 

CRGB leds1[NUM_LEDS];  
CRGB leds2[NUM_LEDS];

CRGB savedLeft[NUM_LEDS]; // left panel previous setting
CRGB savedRight[NUM_LEDS]; // right panel previous setting

uint8_t waveOffset = 0;

// include pink, 0-224 for FastLED red to purple and 224-225 for pink 
CRGB extendHue(uint8_t hue) {
  if(hue < 224) {
    uint8_t fastHue = map(hue, 0, 223, 0, 255); 
    return CHSV(fastHue, 255, 255);
  } else {
    uint8_t t = (hue-224)*8; 
    CRGB purple = CHSV(255, 65,100);
    CRGB pink = CRGB(255, 192, 203);
    return blend(purple, pink, t);
  }
}

// Switch controls
int readSwitch() {
  bool pin1 = digitalRead(SWITCH_PIN1);
  // left -> 0 / pin1=LOW, rgb 
  // middle -> 1 / pin1=HIGH, left panel  
  // right -> 2 / pin2=LOW, right panel
  bool pin2 = digitalRead(8);
  if(!pin1 && pin2) return 0;
  if(pin1 && pin2) return 1; 
  if(pin1 && !pin2) return 2; 
  return 0;
}

// darker color edges and lighter center 
void applyGradient(CRGB* strip, bool leftPanel) {
  for(int i = 0; i < NUM_LEDS; i++) {
    float t;
    if(leftPanel) {
      t = (float)i / (NUM_LEDS - 1); 
    } else {
      t = 1.0f - float(i) / (NUM_LEDS - 1);
    }
    float scale = 0.75f + 0.25f*t;
    strip[i].r = (uint8_t)(strip[i].r * scale);
    strip[i].g = (uint8_t)(strip[i].g * scale);
    strip[i].b = (uint8_t)(strip[i].b * scale);
  }
}

void setup() {
  FastLED.addLeds<WS2812B, LED1_PIN, GRB>(leds1, NUM_LEDS);
  FastLED.addLeds<WS2812B, LED2_PIN, GRB>(leds2, NUM_LEDS);
  FastLED.setBrightness(BRIGHTNESS);

  pinMode(SWITCH_PIN1, INPUT_PULLUP);
  pinMode(8, INPUT_PULLUP);

  for(int i = 0; i < NUM_LEDS; i++) {
    savedLeft[i] = CRGB(128, 0, 128);
    savedRight[i] = CRGB(128, 0, 128);
  }
}

void loop() {
  int mode = readSwitch();
  int potVal = analogRead(POT_PIN);

  // rainbow
  if(mode == 0) {
    int waveDelay = map(potVal, 0, 1023, 50, 1);

    for(int i = 0; i < NUM_LEDS; i++) {
      uint8_t hue = waveOffset + (i * (256/ NUM_LEDS));
      leds1[i] = CHSV(hue, 200, 220);
      leds2[i] = CHSV(hue, 200, 220);
    }
    FastLED.show();
    delay(waveDelay); 
    waveOffset++;
  } else if(mode == 1) {
    uint8_t extHue = map(potVal, 0, 1023, 0, 255); 
    CRGB baseColor = extendHue(extHue);

    for(int i = 0; i < NUM_LEDS; i++) {
      leds1[i] = baseColor;
      savedLeft[i] = leds1[i]; 
      leds2[i] = savedRight[i];
    }
    applyGradient(leds1, true); 
    FastLED.show();
    delay(10);
  } else if(mode == 2) {
    uint8_t extHue = map(potVal, 0, 1023, 0, 255); 
    CRGB baseColor = extendHue(extHue);

    for(int i = 0; i < NUM_LEDS; i++) {
      leds2[i] = baseColor;
      savedRight[i] = leds2[i]; 
      leds1[i] = savedLeft[i];
    }
    applyGradient(leds2, false); 
    FastLED.show();
    delay(10);
  }
}
